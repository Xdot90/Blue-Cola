(() => {
  "use strict";

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  const errorBox = $("#error");
  function showError(msg) {
    errorBox.textContent = msg;
    errorBox.hidden = false;
  }

  // ---------- storage helpers ----------
  const store = {
    get(k, d) { try { return localStorage.getItem(k) ?? d; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch {} },
  };

  // ---------- Service Worker ----------
  let swReady = null;
  async function registerSW() {
    if (!("serviceWorker" in navigator)) {
      throw new Error("Service workers are not supported in this browser.");
    }
    if (location.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(location.hostname)) {
      throw new Error("Service workers need HTTPS (or localhost).");
    }
    await navigator.serviceWorker.register("/sw.js", { scope: __uv$config.prefix });
    await navigator.serviceWorker.ready;
  }
  swReady = registerSW().catch((e) => {
    console.error(e);
    showError("Could not start the proxy service worker: " + e.message);
    throw e;
  });
  swReady.catch(() => {});

  // ---------- URL / search detection ----------
  function toUrl(input, engineTemplate) {
    const value = input.trim();
    if (!value) return null;
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(value)) {
      try { return new URL(value).toString(); } catch {}
    }
    // bare domain like example.com or example.com/path
    if (!/\s/.test(value) && /^([a-z0-9-]+\.)+[a-z]{2,}(:\d+)?(\/.*)?$/i.test(value)) {
      try { return new URL("https://" + value).toString(); } catch {}
    }
    if (/^localhost(:\d+)?(\/.*)?$/i.test(value)) return "http://" + value;
    return engineTemplate.replace("%s", encodeURIComponent(value));
  }

  function proxied(url) {
    return __uv$config.prefix + __uv$config.encodeUrl(url);
  }

  async function ensureSW() {
    try { await swReady; return true; } catch { return false; }
  }

  async function go(input) {
    errorBox.hidden = true;
    const target = toUrl(input, $("#engine").value);
    if (!target) return;
    if (!(await ensureSW())) return;
    location.href = proxied(target);
  }

  // ---------- Home ----------
  $("#search-form").addEventListener("submit", (e) => {
    e.preventDefault();
    go($("#search-input").value);
  });
  $$(".card").forEach((c) => c.addEventListener("click", () => {
    const url = c.dataset.url;
    if (url.includes("movy.sx")) { switchView("movies"); openMovies(); return; }
    go(url);
  }));
  const engineSel = $("#engine");
  engineSel.value = store.get("bc-engine", engineSel.value);
  if (engineSel.selectedIndex < 0) engineSel.selectedIndex = 0;
  engineSel.addEventListener("change", () => store.set("bc-engine", engineSel.value));

  // ---------- Tabs ----------
  function switchView(name) {
    $$(".tab").forEach((t) => t.classList.toggle("active", t.dataset.view === name));
    $$(".view").forEach((v) => v.classList.toggle("active", v.id === "view-" + name));
  }
  $$(".tab").forEach((t) => t.addEventListener("click", () => switchView(t.dataset.view)));

  // ---------- Movies ----------
  const MOVIE_URL = "https://movy.sx";
  const viewer = $("#movie-viewer");
  const frame = $("#movie-frame");
  async function openMovies() {
    errorBox.hidden = true;
    if (!(await ensureSW())) return;
    frame.src = proxied(MOVIE_URL);
    viewer.hidden = false;
    viewer.scrollIntoView({ behavior: "smooth", block: "start" });
  }
  $("#movie-launch").addEventListener("click", openMovies);
  $("#movie-newtab").addEventListener("click", () => go(MOVIE_URL));
  $("#viewer-close").addEventListener("click", () => { frame.src = "about:blank"; viewer.hidden = true; });
  $("#viewer-full").addEventListener("click", () => {
    if (frame.requestFullscreen) frame.requestFullscreen().catch(() => {});
  });

  // ---------- Themes ----------
  const THEMES = [
    ["red", "Red", "#e5262f"],
    ["orange", "Orange", "#ff7a1a"],
    ["yellow", "Yellow", "#f5d90a"],
    ["gold", "Gold", "#d4a017"],
    ["green", "Green", "#1fc15a"],
    ["darkblue", "Dark Blue", "#2f6bff"],
    ["purple", "Purple", "#8b3dff"],
  ];
  const themeWrap = $("#themes");
  function applyTheme(id) {
    document.documentElement.setAttribute("data-theme", id);
    store.set("bc-theme", id);
    $$(".theme-btn", themeWrap).forEach((b) => b.classList.toggle("active", b.dataset.theme === id));
  }
  THEMES.forEach(([id, label, color]) => {
    const b = document.createElement("button");
    b.className = "theme-btn";
    b.dataset.theme = id;
    b.innerHTML = '<span class="sw" style="background:' + color + '"></span><span>' + label + "</span>";
    b.addEventListener("click", () => applyTheme(id));
    themeWrap.appendChild(b);
  });
  applyTheme(store.get("bc-theme", "darkblue"));

  // ---------- Tab cloak ----------
  const cloak = $("#cloak");
  function applyCloak(v) {
    let title = "Blue Cola", icon = "";
    if (v) [title, icon] = v.split("|");
    document.title = title;
    let link = document.querySelector("link[rel~='icon']");
    if (!link && icon) {
      link = document.createElement("link");
      link.rel = "icon";
      document.head.appendChild(link);
    }
    if (link) link.href = icon || "data:,";
  }
  cloak.value = store.get("bc-cloak", "");
  applyCloak(cloak.value);
  cloak.addEventListener("change", () => { store.set("bc-cloak", cloak.value); applyCloak(cloak.value); });
})();
